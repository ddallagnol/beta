<?php

return [
    'password' => 'As senhas devem ter pelo menos seis caracteres e corresponder à confirmação.',
    'reset'    => 'Sua senha foi redefinida!',
    'sent'     => 'Enviamos seu link de redefinição de senha por email!',
    'token'    => 'Este token de redefinição de senha é inválido.',
    'user'     => 'Não conseguimos encontrar um usuário com esse endereço de email.',
    'updated'  => 'Sua senha foi alterada!',
];
